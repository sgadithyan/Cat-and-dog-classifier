# Cat vs Dog Image Classifier

This project builds a lightweight image classification model using MobileNetV2 to distinguish between cats and dogs.

## Approach
- Dataset from Kaggle: [Cats and Dogs Mini Dataset](https://www.kaggle.com/datasets/aleemaparakatta/cats-and-dogs-mini-dataset)
- Data preprocessing includes image resizing and augmentation.
- MobileNetV2 is used with pre-trained weights (ImageNet).
- The model is trained for 5 epochs.
- A submission file (`submission.csv`) is created with test predictions.

## Instructions to Run

1. **Setup Kaggle API**:
   - Place your `kaggle.json` in the root directory or upload it to the notebook session.
   - Run the following in a code cell:
     ```bash
     !mkdir -p ~/.kaggle
     !cp kaggle.json ~/.kaggle/
     !chmod 600 ~/.kaggle/kaggle.json
     ```

2. **Run Notebook**:
   - Execute all cells in `i.ipynb`.
   - The model will download data, preprocess it, train, and create predictions.

3. **Output**:
   - `submission.csv` will be generated with predictions:
     ```
     filename,prediction
     test_001.jpg,dog
     test_002.jpg,cat
     ```

## Model Accuracy
- Training Accuracy: ~93–95%
- Validation Accuracy: ~88–92%